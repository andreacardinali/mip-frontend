Bundle per correggere i 6 errori ESLint.

Esecuzione:
  cd /opt/mip/mip-frontend
  unzip -o /percorso/mip-frontend-lint-fix.zip -d /tmp/mip-frontend-lint-fix
  /tmp/mip-frontend-lint-fix/apply.sh /opt/mip/mip-frontend

Il bundle contiene i tre file completi modificati e applica in modo deterministico
le due sole sostituzioni di tipo nei due file molto grandi delle pagine dettagli.
Alla fine esegue automaticamente npm run lint e npm run build.
