#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/opt/mip/mip-frontend}"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

install -m 0644 "$BUNDLE_DIR/src/contexts/AuthProvider.tsx" \
  "$ROOT/src/contexts/AuthProvider.tsx"
install -m 0644 "$BUNDLE_DIR/src/contexts/PriceRefreshProvider.tsx" \
  "$ROOT/src/contexts/PriceRefreshProvider.tsx"
install -m 0644 "$BUNDLE_DIR/src/pages/SettingsPage.tsx" \
  "$ROOT/src/pages/SettingsPage.tsx"

python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys

root = Path(sys.argv[1])
replacements = {
    root / "src/pages/PortfolioDetailsPage.tsx": (
        ".map((row: any) => String(row.position_id))",
        ".map((row: PositionRow) => String(row.position_id))",
    ),
    root / "src/pages/WatchlistDetailsPage.tsx": (
        ".map((row: any) => String(row.watchlist_item_id))",
        ".map((row: GridRowModel) => String(row.watchlist_item_id))",
    ),
}

for path, (old, new) in replacements.items():
    content = path.read_text(encoding="utf-8")
    if old not in content:
        raise SystemExit(f"Pattern not found in {path}: {old}")
    path.write_text(content.replace(old, new, 1), encoding="utf-8")
    print(f"Updated {path}")
PY

cd "$ROOT"
npm run lint
npm run build
